package com.pjpratikjain7.schooldiary.utils;

public class Constants
{

//    public static final String httpurl = "http://172.18.4.169:5000";
public static final String httpurl = "http://192.168.2.118:5000";

    public static final String ROUTE_USER = "user";
    public static final String ROUTE_PARENT = "parent";
    public static final String ROUTE_STUDENT = "student";
}
