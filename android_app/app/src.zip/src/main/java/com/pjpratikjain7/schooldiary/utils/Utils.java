package com.pjpratikjain7.schooldiary.utils;

public class Utils
{
    public static String  createRoute(String route)
    {
        return Constants.httpurl + "/" + route;
    }
}
